
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders, status: 204 })
  }

  try {
    // Create Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    
    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('Missing environment variables: SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY')
      return new Response(
        JSON.stringify({ 
          error: 'Server configuration error',
          sessions: [] 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      )
    }
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey)
    
    // Get auth header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      return new Response(
        JSON.stringify({ 
          error: 'No authorization header provided',
          sessions: [] 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 401 }
      )
    }
    
    // Get the token from the auth header
    const token = authHeader.replace('Bearer ', '')
    
    // Verify the user with the token
    const { data: { user }, error: userError } = await supabase.auth.getUser(token)
    
    if (userError || !user) {
      console.error('User verification error:', userError)
      return new Response(
        JSON.stringify({ 
          error: 'Invalid token or user not found',
          sessions: [] 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 401 }
      )
    }
    
    console.log(`Fetching sessions for user ${user.id}`)
    
    try {
      // Use the RPC function to get user sessions
      const { data: rpcData, error: rpcError } = await supabase
        .rpc('apl_get_user_sessions', { user_id_param: user.id })
      
      if (rpcError) {
        console.error('Error fetching sessions via RPC:', rpcError)
        throw rpcError
      }
      
      // Process RPC data
      const currentSessionId = token.split('.')[0]
      console.log('RPC sessions data:', JSON.stringify(rpcData))
      
      // Deduplicate sessions - some sessions might appear twice in the data
      const sessionMap = new Map()
      
      if (Array.isArray(rpcData) && rpcData !== null) {
        rpcData.forEach(session => {
          // If this is the current session, mark it
          const isCurrentSession = session.id === currentSessionId
          
          // If we haven't seen this session yet, or if this is the current session, add/update it
          if (!sessionMap.has(session.id) || isCurrentSession) {
            sessionMap.set(session.id, {
              ...session,
              isCurrentDevice: isCurrentSession
            })
          }
        })
      }
      
      const processedSessions = Array.from(sessionMap.values())
      
      // Make sure the current session is included
      if (processedSessions.length === 0 || !processedSessions.some(s => s.isCurrentDevice)) {
        const currentSession = {
          id: currentSessionId,
          created_at: new Date().toISOString(),
          user_agent: req.headers.get('User-Agent') || 'Unknown',
          ip_address: req.headers.get('X-Forwarded-For') || 'Unknown',
          last_active_at: new Date().toISOString(),
          isCurrentDevice: true
        }
        
        processedSessions.unshift(currentSession)
      }
      
      return new Response(
        JSON.stringify({ sessions: processedSessions }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      )
    } catch (error) {
      console.error('Unexpected error fetching sessions:', error)
      
      // Create a fallback session from the current request
      const currentSession = {
        id: token.split('.')[0],
        created_at: new Date().toISOString(),
        user_agent: req.headers.get('User-Agent') || 'Unknown',
        ip_address: req.headers.get('X-Forwarded-For') || 'Unknown',
        last_active_at: new Date().toISOString(),
        isCurrentDevice: true
      }
      
      return new Response(
        JSON.stringify({ 
          error: 'Error fetching sessions',
          sessions: [currentSession] 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      )
    }
  } catch (error) {
    console.error('Unexpected error:', error)
    
    // Create a fallback session from the current request
    const currentSession = {
      id: req.headers.get('Authorization')?.replace('Bearer ', '').split('.')[0] || 'unknown',
      created_at: new Date().toISOString(),
      user_agent: req.headers.get('User-Agent') || 'Unknown',
      ip_address: req.headers.get('X-Forwarded-For') || 'Unknown',
      last_active_at: new Date().toISOString(),
      isCurrentDevice: true
    }
    
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error', 
        message: error.message,
        sessions: [currentSession] 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    )
  }
})
